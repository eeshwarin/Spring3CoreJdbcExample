package com.sanjaya.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.sanjaya.pojos.HelloConfiguration;

@Configuration
public class MySpringConfig {
	
	@Bean
	@Scope("singleton")
	public HelloConfiguration helloConfiguration(){
		/*HelloWorld h = new HelloWorld();//setter injection
		h.setMessage("HIIIII");//setter injection
		return h;//setter injection
*/		return new HelloConfiguration("Helloooooooooooooo");//constructor injection
		
	}

}
