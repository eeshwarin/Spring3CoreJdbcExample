package com.sanjaya.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.sanjaya.pojos.HelloConfiguration;

@Configuration
public class MyJavaConfig {

	public MyJavaConfig() {
		// TODO Auto-generated constructor stub
	}
	
	@Bean
	@Scope("singleton")
	public HelloConfiguration helloConfiguration(){
		
		return new HelloConfiguration("Hey I am from Java based configuration");
	}

}
