/**
 * 
 */
package com.sanjaya.pojos;

/**
 * @author 498266
 *
 */
public class Pen {

	/**
	 * 
	 */
	public Pen() {}
	
	private String color;
	private double cost;
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the cost
	 */
	public double getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Pen [color=" + color + ", cost=" + cost + "]";
	}
	
	

}
