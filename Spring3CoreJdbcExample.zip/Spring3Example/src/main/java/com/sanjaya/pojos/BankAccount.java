package com.sanjaya.pojos;

public class BankAccount {
	
	private int accountNumber;
	private String bankName;
	private String branchName;
	
	public BankAccount(){}
	
	public BankAccount(int accountNumber, String bankName, String branchName) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.branchName = branchName;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", bankName="
				+ bankName + ", branchName=" + branchName + "]";
	}
	
	

}
