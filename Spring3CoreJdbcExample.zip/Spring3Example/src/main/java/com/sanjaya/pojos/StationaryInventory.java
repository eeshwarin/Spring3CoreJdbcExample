package com.sanjaya.pojos;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class StationaryInventory {
	
	private List<Book> books;
	private Set<Disk> disks;
	private List<Pen> pens;

	public StationaryInventory()
	{
		books=new ArrayList<Book>();
		disks=new TreeSet<Disk>();
		pens=new ArrayList<Pen>();
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public Set<Disk> getDisks() {
		return disks;
	}

	public void setDisks(Set<Disk> disks) {
		this.disks = disks;
	}

	/**
	 * @return the pens
	 */
	public List<Pen> getPens() {
		return pens;
	}

	/**
	 * @param pens the pens to set
	 */
	public void setPens(List<Pen> pens) {
		this.pens = pens;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "StationaryInventory [books=" + books + ", disks=" + disks
				+ ", pens=" + pens + "]";
	}
	
	
	
	
}
