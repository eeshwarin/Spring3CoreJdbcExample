package com.sanjaya.annotation.pojos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("cust1")
public class Customer {
	
	@Value("101")
	private int custId;
	@Value("SKD")
	private String name;
	@Value("111.0")
	private double sal;
	@Autowired
	private Address address;
	
	public Customer(){}
	
	public Customer(int custId, String name, double sal, Address address) {
		super();
		this.custId = custId;
		this.name = name;
		this.sal = sal;
		this.address = address;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", sal=" + sal
				+ ", address=" + address + "]";
	}

}
