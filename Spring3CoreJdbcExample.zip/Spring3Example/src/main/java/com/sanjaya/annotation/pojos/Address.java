package com.sanjaya.annotation.pojos;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Address {
	@Value("10")
	private int streetNumber;
	@Value("nagavaraStreet")
	private String streetName;
	@Value("Bangalore")
	private String cityName;
	
	public Address(){}
	
	public Address(int streetNumber, String streetName, String cityName) {
		super();
		this.streetNumber = streetNumber;
		this.streetName = streetName;
		this.cityName = cityName;
	}

	public int getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(int streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	@Override
	public String toString() {
		return "Address [streetNumber=" + streetNumber + ", streetName="
				+ streetName + ", cityName=" + cityName + "]";
	}

}
