package com.sanjaya.annotation.pojos;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("acc1")
public class BankAccountSpEL {
	@Value("20106")
	private int accountNumber;
	@Value("SBI")
	private String bankName;
	@Value("Manyatha")
	private String branchName;
	
	public BankAccountSpEL(){}
	
	public BankAccountSpEL(int accountNumber, String bankName, String branchName) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.branchName = branchName;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "BankAccountSpEL [accountNumber=" + accountNumber + ", bankName="
				+ bankName + ", branchName=" + branchName + "]";
	}
	
	

}
