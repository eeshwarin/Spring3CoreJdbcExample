package com.sanjaya.jdbcdemo.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbcdemo.pojo.ItemPurchaseInvoice;

@Repository("itemPurchaseInvoiceRowMapper")
public class ItemPurchaseInvoiceRowMapper implements RowMapper<ItemPurchaseInvoice> {
	
	public ItemPurchaseInvoice mapRow(ResultSet rs, int rowId) throws SQLException {
		return new ItemPurchaseInvoice(rs.getInt("invoiceNum"), rs.getInt("iCode"), 
				rs.getString("dealer"), rs.getDouble("costPrice"));
	}

}
