package com.sanjaya.jdbcdemo.daos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.MappingSqlQueryWithParameters;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbcdemo.pojo.Item;
import com.sanjaya.jdbcdemo.rowmappers.ItemRowMapper;

@Repository("itemDAO3")
public class ItemDAO3 {
	
	//@Autowired
	//@Qualifier("datasource")
	private DataSource dataSource;
	@Autowired
	@Qualifier("itemRowMapper")
	private ItemRowMapper rowMapper;

	private SqlUpdate insertQuery;
	private SqlUpdate updateQuery;
	private SqlUpdate deleteQuery;
	//private MappingSqlQuery<Item> getItemQuery;
	private MappingSqlQueryWithParameters<Item> getItemQuery;
	private MappingSqlQuery<Item> getAllItemsQry;

	public ItemDAO3() {
	}

	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	@Qualifier("datasource")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		initQuerys();
		
	}
	
	@SuppressWarnings("unchecked")
	public void initQuerys(){
		insertQuery = new SqlUpdate(dataSource, "insert into Item values(?,?,?)");
		updateQuery = new SqlUpdate(dataSource, "update Item set iname=?,iprice=? where icode=?");
		deleteQuery = new SqlUpdate(dataSource, "delete from Item where icode=?");
		
		SqlParameter param1 = new SqlParameter("icode",Types.INTEGER);
		SqlParameter param2 = new SqlParameter("iname",Types.VARCHAR);
		SqlParameter param3 = new SqlParameter("iprice",Types.DECIMAL);
		
		insertQuery.declareParameter(param1);
		insertQuery.declareParameter(param2);
		insertQuery.declareParameter(param3);
		insertQuery.compile();
		
		updateQuery.declareParameter(param1);
		updateQuery.declareParameter(param2);
		updateQuery.declareParameter(param3);
		updateQuery.compile();
		
		deleteQuery.declareParameter(param1);
		deleteQuery.compile();
		
		getAllItemsQry = new MappingSqlQuery<Item>(dataSource, "select icode, iname, iprice from Item"){
			protected Item mapRow(ResultSet rs, int rowNum)throws SQLException{
				
				//return new Item(rs.getInt("icode"), rs.getString("icode"),rs.getDouble("iprice"));
				return rowMapper.mapRow(rs, rowNum);
			}
		};
		getAllItemsQry.compile();
		
		/*getItemQuery = new MappingSqlQuery<Item>(dataSource, "select * from Item where icode=?") {
			protected Item mapRow(ResultSet rs, int rowNum) throws SQLException{
				
				//return new Item(rs.getInt("icode"), rs.getString("icode"),rs.getDouble("iprice"));
				return rowMapper.mapRow(rs, rowNum);
			}
		};
		
		getItemQuery.declareParameter(param1);
		getItemQuery.compile();*/
		
		//getItemQuery = new MappingSqlQuery(dataSource, "select * from Item where icode=?"){

			  
			 /*protected Item mapRow(ResultSet rs, int rowNum) throws SQLException{
				
				//return new Item(rs.getInt("icode"), rs.getString("icode"),rs.getDouble("iprice"));
				return rowMapper.mapRow(rs, rowNum);
			}*/
		getItemQuery = new MappingSqlQueryWithParameters(dataSource, "select * from Item where iprice=?"){
			protected Item mapRow(ResultSet rs, int rowNum, Object[] arg2,
					Map arg3) throws SQLException {
				return rowMapper.mapRow(rs, rowNum);
			}
		};
		//getItemQuery.declareParameter(param1);
		getItemQuery.declareParameter(param3);
		getItemQuery.compile();
		
	}
	
	/*@Autowired
	@Qualifier("customerExceptionTranslator")
	@Required
	public void setCustomerExceptionTranslator(CustomerExceptionTranslator cet) {
		this.jdbcTemplate.setExceptionTranslator(cet);
	}*/
	
	public void addItem(Item item){
			insertQuery.update(item.getiCode(), item.getiName(), item.getiPrice());
	}
	
	public void updateItem(Item item){
		updateQuery.update(item.getiCode(), item.getiName(), item.getiPrice());
	}
	
	public void removeItem(Item item){
		deleteQuery.update(item.getiCode());
	}
	
	public Item getItem(int iCode){
		return getItemQuery.findObject(iCode);
	}
	
	public List<Item> getItems(){		
		return getAllItemsQry.execute();
	}

	
	public ItemRowMapper getRowMapper() {
		return rowMapper;
	}

	public void setRowMapper(ItemRowMapper rowMapper) {
		this.rowMapper = rowMapper;
	}
}
