package com.sanjaya.jdbcdemo.daos;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.sanjaya.jdbcdemo.pojo.Item;
import com.sanjaya.jdbcdemo.pojo.ItemPurchaseInvoice;
import com.sanjaya.jdbcdemo.rowmappers.ItemPurchaseInvoiceRowMapper;
import com.sanjaya.jdbcdemo.rowmappers.ItemRowMapper;

@Repository("annotationBasedItemPurchaseInvoiceDAO")
public class AnnotationBasedItemPurchaseInvoiceDAO {
	
	//@Autowired
	//@Qualifier("datasource")
	private DataSource dataSource;

	
	@Autowired
	@Qualifier("itemRowMapper")
	private ItemRowMapper rowMapper;
	
	@Autowired
	@Qualifier("itemPurchaseInvoiceRowMapper")
	private ItemPurchaseInvoiceRowMapper itemPurchaseInvoiceRowMapper;
	
	private JdbcTemplate jdbcTemplate;

	public AnnotationBasedItemPurchaseInvoiceDAO() {
		this.jdbcTemplate = new JdbcTemplate();
	}

	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	@Qualifier("datasource")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate.setDataSource(dataSource);
	}
	
	
	public ItemPurchaseInvoiceRowMapper getItemPurchaseInvoiceRowMapper() {
		return itemPurchaseInvoiceRowMapper;
	}

	public void setItemPurchaseInvoiceRowMapper(
			ItemPurchaseInvoiceRowMapper itemPurchaseInvoiceRowMapper) {
		this.itemPurchaseInvoiceRowMapper = itemPurchaseInvoiceRowMapper;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	@Transactional
	public void addItemAndInvoice(final Item item, final ItemPurchaseInvoice itemPurchaseInvoice){
			
		
				String itemSql = "insert into item values(?,?,?)";
				jdbcTemplate.update(itemSql, item.getiCode(), item.getiName(), item.getiPrice());
				
				String itemInvPurSql = "insert into ItemPurchaseInvoice values(?,?,?,?)";
				jdbcTemplate.update(itemInvPurSql, itemPurchaseInvoice.getInvoiceNum(), itemPurchaseInvoice.getiCode(), itemPurchaseInvoice.getDealer(), itemPurchaseInvoice.getCostPrice());	
		
	}
	
	
	
	/*public void removeItemAndInvoice(Item item, ItemPurchaseInvoice itemPurchaseInvoice){
		DefaultTransactionDefinition txDef = new DefaultTransactionDefinition();
		txDef.setTimeout(25000);
		TransactionStatus txStatus = txManager.getTransaction(txDef);
		try{
		String itemSql = "delete from Item where icode=?";
		jdbcTemplate.update(itemSql, item.getiCode());
		
		String itemInvPurSql = "delete from ItemPurchaseInvoice where invoiceNum=?";
		jdbcTemplate.update(itemInvPurSql, itemPurchaseInvoice.getInvoiceNum());
		
		txManager.commit(txStatus);
		}catch(DataAccessException exception){
			exception.printStackTrace();
			txManager.rollback(txStatus);
		}
	}*/
	
	/*public void updateItem(Item item){
		updateQuery.update(item.getiCode(), item.getiName(), item.getiPrice());
	}
	
	public void removeItem(Item item){
		deleteQuery.update(item.getiCode());
	}
	
	public Item getItem(int iCode){
		return getItemQuery.findObject(iCode);
	}
	
	public List<Item> getItems(){		
		return getAllItemsQry.execute();
	}*/

	
	public ItemRowMapper getRowMapper() {
		return rowMapper;
	}

	public void setRowMapper(ItemRowMapper rowMapper) {
		this.rowMapper = rowMapper;
	}
}
