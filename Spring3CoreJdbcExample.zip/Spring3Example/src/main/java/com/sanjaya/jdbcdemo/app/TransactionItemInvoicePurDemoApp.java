package com.sanjaya.jdbcdemo.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.jdbcdemo.daos.AnnotationBasedItemPurchaseInvoiceDAO;
import com.sanjaya.jdbcdemo.pojo.Item;
import com.sanjaya.jdbcdemo.pojo.ItemPurchaseInvoice;

public class TransactionItemInvoicePurDemoApp {

	public static void main(String[] args) {
		
		//ApplicationContext context = new ClassPathXmlApplicationContext("conf/TransactionTemplateConfBeans.xml");
		ApplicationContext context = new ClassPathXmlApplicationContext("AnnotationalTransactionConfBeans.xml");
		

	      Item item1 = (Item) context.getBean("item");
	      item1.setiCode(201);
	      item1.setiName("Rice 422");
	      item1.setiPrice(900);
	      /*Item item2 = (Item) context.getBean("item");
	      item2.setiCode(105);
	      item2.setiName("Rice 5");
	      item2.setiPrice(900);
	      Item item3 = (Item) context.getBean("item");
	      item3.setiCode(106);
	      item3.setiName("Rice 6");
	      item3.setiPrice(1000);*/
	      
	      ItemPurchaseInvoice itemPurchaseInvoice = (ItemPurchaseInvoice) context.getBean("itemPurchaseInvoice");
	      itemPurchaseInvoice.setInvoiceNum(4051);
	      itemPurchaseInvoice.setiCode(item1.getiCode());
	      itemPurchaseInvoice.setDealer("SriRam");
	      itemPurchaseInvoice.setCostPrice(2050);
	      
	      AnnotationBasedItemPurchaseInvoiceDAO annotationBasedItemPurchaseInvoiceDAO = (AnnotationBasedItemPurchaseInvoiceDAO) context.getBean("annotationBasedItemPurchaseInvoiceDAO");
	      
	      annotationBasedItemPurchaseInvoiceDAO.addItemAndInvoice(item1, itemPurchaseInvoice);
	      System.out.println("Saved into database!!!");
	      
	      /*itemPurchaseInvoiceDAO.removeItemAndInvoice(item1, itemPurchaseInvoice);
	      System.out.println("Record removed from database!!!");*/


	}

}
