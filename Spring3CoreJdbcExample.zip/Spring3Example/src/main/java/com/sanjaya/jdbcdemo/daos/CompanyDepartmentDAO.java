package com.sanjaya.jdbcdemo.daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbcdemo.rowmappers.CompanyRowMapper;
import com.sanjaya.jdbctemplate.pojo.Company;
import com.sanjaya.jdbctemplate.pojo.Department;


@Repository("companyDepartmentDAO")
public class CompanyDepartmentDAO {
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public CompanyDepartmentDAO() {
		this.jdbcTemplate = new JdbcTemplate();
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public DataSource getDataSource() {
		return dataSource;
	}
	
	@Autowired
	@Qualifier("datasource")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate.setDataSource(dataSource);
	}
	
	@Autowired
	@Qualifier("companyRowMapper")
	private CompanyRowMapper companyRowMapper;

	public CompanyRowMapper getCompanyRowMapper() {
		return companyRowMapper;
	}
	public void setCompanyRowMapper(CompanyRowMapper companyRowMapper) {
		this.companyRowMapper = companyRowMapper;
	}

	public void addCompany(Company company, Department department){
		
		String sql = "insert into company values(?,?,?)";
		this.jdbcTemplate.update(sql, new Object[] {company.getCompanyName(), company.getCompanyLevel(), company.getCompanyRevenue()});
		
		String sql1 = "insert into department values(?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[] {department.getDeptName(), department.getVertical(), 
				department.getRevenue(), department.getCompanyName()});
	}
	
	public Company getCompany(String companyName){
		
		String sql = "select * from company where name=?";
		return jdbcTemplate.queryForObject(sql, new Object[] {companyName}, companyRowMapper);
	}
	
	public List<Company> getAllCompanies(){
		
		String sql = "select * from company";
		return jdbcTemplate.query(sql, companyRowMapper);
	}
	
	public void updateCompany(Company company){
		String sql = "update company set level=?, revenue=? where name=?";
		jdbcTemplate.update(sql, new Object[] {company.getCompanyLevel(), company.getCompanyRevenue(), company.getCompanyName()});
	}
	
	public void deleteCompany(Company company){
		String sql = "delete from company where name=?";
		jdbcTemplate.update(sql, new Object[] {company.getCompanyName()});
	}
	
	
	
	

}
