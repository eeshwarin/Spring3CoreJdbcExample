package com.sanjaya.jdbcdemo.pojo;

import java.io.Serializable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("itemPurchaseInvoice")
@Scope("prototype")
public class ItemPurchaseInvoice implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int invoiceNum;
	private int iCode;
	private String dealer;
	private double costPrice;
	
	public ItemPurchaseInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemPurchaseInvoice(int invoiceNum, int iCode, String dealer,
			double costPrice) {
		super();
		this.invoiceNum = invoiceNum;
		this.iCode = iCode;
		this.dealer = dealer;
		this.costPrice = costPrice;
	}

	public int getInvoiceNum() {
		return invoiceNum;
	}

	public void setInvoiceNum(int invoiceNum) {
		this.invoiceNum = invoiceNum;
	}

	public int getiCode() {
		return iCode;
	}

	public void setiCode(int iCode) {
		this.iCode = iCode;
	}

	public String getDealer() {
		return dealer;
	}

	public void setDealer(String dealer) {
		this.dealer = dealer;
	}

	public double getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}

	@Override
	public String toString() {
		return "ItemPurchaseInvoice [invoiceNum=" + invoiceNum + ", iCode="
				+ iCode + ", dealer=" + dealer + ", costPrice=" + costPrice
				+ "]";
	}

}
