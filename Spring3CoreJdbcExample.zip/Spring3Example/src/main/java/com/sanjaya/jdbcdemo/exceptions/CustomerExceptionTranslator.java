package com.sanjaya.jdbcdemo.exceptions;

import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLExceptionTranslator;
import org.springframework.stereotype.Repository;

@Repository("customerExceptionTranslator")
public class CustomerExceptionTranslator implements SQLExceptionTranslator {

	public DataAccessException translate(String task, String sql,
			SQLException exception) {

		return new CustomerException("sdfd"+exception);
	}

}

class CustomerException extends DataAccessException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerException(String msg){
		super(msg);
	}
	
}
