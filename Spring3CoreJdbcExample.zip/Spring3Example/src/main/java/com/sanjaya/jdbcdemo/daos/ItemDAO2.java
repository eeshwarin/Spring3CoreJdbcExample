package com.sanjaya.jdbcdemo.daos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbcdemo.pojo.Item;
import com.sanjaya.jdbcdemo.rowmappers.ItemRowMapper;

@Repository("itemDAO2")
public class ItemDAO2 {
	
	//@Autowired
	//@Qualifier("datasource")
	private DataSource dataSource;
	@Autowired
	@Qualifier("itemRowMapper")
	private ItemRowMapper rowMapper;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public ItemDAO2() {
	}

	public ItemRowMapper getRowMapper() {
		return rowMapper;
	}

	public void setRowMapper(ItemRowMapper rowMapper) {
		this.rowMapper = rowMapper;
	}
	
	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	@Qualifier("datasource")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		//this.jdbcTemplate = new JdbcTemplate();
		//this.jdbcTemplate.setDataSource(dataSource);
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}
	
	
	/*@Autowired
	@Qualifier("customerExceptionTranslator")
	@Required
	public void setCustomerExceptionTranslator(CustomerExceptionTranslator cet) {
		this.namedParameterJdbcTemplate.setExceptionTranslator(cet);//does not support
		//SimpleJdbcTemplate jd = new SimpleJdbcTemplate();
	}*/
	
	public void addItem(Item item){
			String sql = "insert into Item values(:iCode,:iName,:iPrice)";
			BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(item);
			//SqlParameterSource param = new MapSqlParameterSource("iCode", item.getiCode()).addValue("iName", item.getiName()).addValue("iPrice", item.getiPrice());
			namedParameterJdbcTemplate.update(sql, param);
	}
	
	public void updateItem(Item item){
			String sql = "update Item set iname=:iName, iprice=:iPrice where icode=:iCode";
			BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(item);
			namedParameterJdbcTemplate.update(sql, param);
	}
	
	public void removeItem(Item item){
			String sql = "delete from Item where icode=:iCode";
			BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(item);
			namedParameterJdbcTemplate.update(sql, param);
	}
	
	public Item getItem(int iCode){
		String sql = "select * from Item where icode=:iCode";
		
		//One Way
		/*Map param = Collections.singletonMap("iCode", iCode);
		return namedParameterJdbcTemplate.queryForObject(sql, param, rowMapper);*/
		
		//Another way
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource("iCode", iCode);
		return namedParameterJdbcTemplate.queryForObject(sql, sqlParameterSource, rowMapper);
	}
	
	public List<Item> getItems(){
		String sql = "select * from Item";
		//return namedParameterJdbcTemplate.query(sql, rowMapper);	
		return new ArrayList();
	}
}
