package com.sanjaya.jdbcdemo.daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbcdemo.exceptions.CustomerExceptionTranslator;
import com.sanjaya.jdbcdemo.pojo.Item;
import com.sanjaya.jdbcdemo.rowmappers.ItemRowMapper;

@Repository("itemDAO")
public class ItemDAO {
	
	//@Autowired
	//@Qualifier("datasource")
	private DataSource dataSource;
	@Autowired
	@Qualifier("itemRowMapper")
	private ItemRowMapper rowMapper;

	private JdbcTemplate jdbcTemplate;

	public ItemDAO() {
		this.jdbcTemplate = new JdbcTemplate();
	}

	public DataSource getDataSource() {
		return dataSource;
	}
	@Autowired
	@Qualifier("datasource")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		//this.jdbcTemplate = new JdbcTemplate();
		this.jdbcTemplate.setDataSource(dataSource);
	}
	
	@Autowired
	@Qualifier("customerExceptionTranslator")
	@Required
	public void setCustomerExceptionTranslator(CustomerExceptionTranslator cet) {
		this.jdbcTemplate.setExceptionTranslator(cet);
	}
	
	public void addItem(Item item){
			String sql = "insert into Item values(?,?,?)";
			jdbcTemplate.update(sql, item.getiCode(), item.getiName(), item.getiPrice());
	}
	
	public void updateItem(Item item){
			String sql = "update Item set iname=?, iprice=? where icode=? ";
			jdbcTemplate.update(sql, item.getiName(), item.getiPrice(), item.getiCode());
	}
	
	public void removeItem(Item item){
			String sql = "delete from Item where icode=?";
			jdbcTemplate.update(sql, item.getiCode());
	}
	
	public Item getItem(int iCode){
		String sql = "select * from Item where icode=?";
		return jdbcTemplate.queryForObject(sql, new Object[] {iCode}, rowMapper);
	}
	
	public List<Item> getItems(){
		String sql = "select * from Item";
		return jdbcTemplate.query(sql, rowMapper);
	}

	
	public ItemRowMapper getRowMapper() {
		return rowMapper;
	}

	public void setRowMapper(ItemRowMapper rowMapper) {
		this.rowMapper = rowMapper;
	}
	
}
