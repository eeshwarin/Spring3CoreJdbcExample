package com.sanjaya.jdbcdemo.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sanjaya.jdbctemplate.pojo.Company;


@Repository("companyRowMapper")
public class CompanyRowMapper implements RowMapper<Company> {


	public Company mapRow(ResultSet rs, int rowId) throws SQLException {
		/*Company company = new Company();
		company.setCompanyName(rs.getString("name"));
		company.setCompanyLevel(rs.getString("level"));
		company.setCompanyRevenue(rs.getLong("revenue"));*/
		return new Company(rs.getString("name"), rs.getString("level"), rs.getLong("revenue"));
	}
	


}
