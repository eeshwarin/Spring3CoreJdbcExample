package com.sanjaya.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.pojos.Employee;

public class PropertyInjectionDemoApp {

	public static void main(String[] args) {
		 
		ApplicationContext context = 
	             new ClassPathXmlApplicationContext("Beans.xml");

	      Employee obj = (Employee) context.getBean("emp1");

	      System.out.println(obj);

	}

}
