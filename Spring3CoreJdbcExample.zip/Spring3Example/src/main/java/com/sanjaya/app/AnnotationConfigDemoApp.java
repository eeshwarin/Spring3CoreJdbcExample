package com.sanjaya.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.annotation.pojos.Employee;
import com.sanjaya.annotation.pojos.EmployeeSpEL;
import com.sanjaya.annotation.pojos.Customer;



public class AnnotationConfigDemoApp {
	
	public static void main(String[] args) {
		
		int firstArg;
		if (args.length > 0) {
		    try {
		        firstArg = Integer.parseInt(args[0]);
		        if(firstArg<1 || firstArg>3){
		        	System.out.println("Please enter digit in between 1 and 3");
		        }
		    } catch (NumberFormatException e) {
		        System.err.println("Argument" + args[0] + " must be an integer.");
		        System.exit(1);
		    }
		}
		
		 
		/*ApplicationContext context = 
	             new ClassPathXmlApplicationContext("AnnotationBeans.xml");

	      Employee obj = (Employee) context.getBean("emp1");*/

		/*ApplicationContext context = 
	             new ClassPathXmlApplicationContext("AnnotationBeans.xml");

	      Customer obj = (Customer) context.getBean("cust1");*/
		/*ApplicationContext context = 
	             new ClassPathXmlApplicationContext("AnnotationBeans.xml");

	      EmployeeSpEL obj = (EmployeeSpEL) context.getBean("emp2");
		
	      
	      System.out.println(obj);
	      System.out.println("Derived AccNum : "+obj.getAccNum());*/
	      
	      

	}

}
