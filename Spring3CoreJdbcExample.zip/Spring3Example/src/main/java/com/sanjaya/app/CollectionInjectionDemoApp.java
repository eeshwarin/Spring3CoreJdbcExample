package com.sanjaya.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.pojos.StationaryInventory;

public class CollectionInjectionDemoApp {

	public static void main(String[] args) {
		 
		ApplicationContext context = 
	             new ClassPathXmlApplicationContext("Beans.xml");

	      StationaryInventory obj = (StationaryInventory) context.getBean("inv1");

	      System.out.println(obj);

	}

}
