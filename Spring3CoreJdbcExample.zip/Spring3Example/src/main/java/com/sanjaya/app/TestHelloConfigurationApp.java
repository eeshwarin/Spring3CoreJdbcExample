package com.sanjaya.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sanjaya.pojos.HelloConfiguration;

public class TestHelloConfigurationApp {

	public static void main(String[] args) {
		 
		/*ApplicationContext context = 
	             new ClassPathXmlApplicationContext("conf/Beans.xml");*/

	      //HelloWorld obj = (HelloWorld) context.getBean("helloWorld");

	      //System.out.println(obj.getMessage());
		
		ApplicationContext context = new AnnotationConfigApplicationContext(com.sanjaya.configuration.MyJavaConfig.class);
		
		HelloConfiguration obj = (HelloConfiguration) context.getBean("helloConfiguration");
		
		System.out.println("Message : " + obj.getMessage());
		
		//System.out.println("Do First called : "+obj.doFirst());
		

	}

}
