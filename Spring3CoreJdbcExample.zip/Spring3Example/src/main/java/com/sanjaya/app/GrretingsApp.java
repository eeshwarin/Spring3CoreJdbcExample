package com.sanjaya.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.pojos.Greetings;

public class GrretingsApp {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		Greetings greetings = (Greetings) context.getBean("greetings");
		System.out.println("Greetings for the day : "+greetings.getMessage());

	}

}
