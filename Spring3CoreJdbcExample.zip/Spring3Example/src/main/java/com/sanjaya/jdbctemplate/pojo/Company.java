package com.sanjaya.jdbctemplate.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("company")
@Scope("prototype")
public class Company {
	
	private String companyName;
	private String companyLevel;
	private long companyRevenue;

	public Company() {}

	public Company(String companyName, String companyLevel,
			long companyRevenue) {
		super();
		this.companyName = companyName;
		this.companyLevel = companyLevel;
		this.companyRevenue = companyRevenue;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the companyLevel
	 */
	public String getCompanyLevel() {
		return companyLevel;
	}

	/**
	 * @param companyLevel the companyLevel to set
	 */
	public void setCompanyLevel(String companyLevel) {
		this.companyLevel = companyLevel;
	}

	/**
	 * @return the companyRevenue
	 */
	public double getCompanyRevenue() {
		return companyRevenue;
	}

	/**
	 * @param companyRevenue the companyRevenue to set
	 */
	public void setCompanyRevenue(long companyRevenue) {
		this.companyRevenue = companyRevenue;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ", companyLevel="
				+ companyLevel + ", companyRevenue=" + companyRevenue + "]";
	}
	
}
