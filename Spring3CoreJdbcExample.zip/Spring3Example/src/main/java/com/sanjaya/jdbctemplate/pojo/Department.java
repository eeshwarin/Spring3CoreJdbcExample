package com.sanjaya.jdbctemplate.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("department")
@Scope("prototype")
public class Department {
	
	private String vertical;
	private String deptName;
	private double revenue;
	private String companyName;

	public Department() {}

	public Department(String vertical, String deptName, double revenue,
			String companyName) {
		super();
		this.vertical = vertical;
		this.deptName = deptName;
		this.revenue = revenue;
		this.companyName = companyName;
	}

	/**
	 * @return the vertical
	 */
	public String getVertical() {
		return vertical;
	}

	/**
	 * @param vertical the vertical to set
	 */
	public void setVertical(String vertical) {
		this.vertical = vertical;
	}

	/**
	 * @return the deptName
	 */
	public String getDeptName() {
		return deptName;
	}

	/**
	 * @param deptName the deptName to set
	 */
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/**
	 * @return the revenue
	 */
	public double getRevenue() {
		return revenue;
	}

	/**
	 * @param revenue the revenue to set
	 */
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Department [vertical=" + vertical + ", deptName=" + deptName
				+ ", revenue=" + revenue + ", companyName=" + companyName + "]";
	}
}
