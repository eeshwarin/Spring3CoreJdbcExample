package com.sanjaya.jdbc.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.jdbcdemo.daos.ItemDAO3;
import com.sanjaya.jdbcdemo.pojo.Item;

public class JdbcDemoApp3 {
	
	public static void main(String[] args) {
		 
		ApplicationContext context = 
	             new ClassPathXmlApplicationContext("JdbcDaoDemoConfBeans.xml");

	      /*Item item1 = (Item) context.getBean("item");
	      item1.setiCode(104);
	      item1.setiName("Rice 4");
	      item1.setiPrice(800);
	      Item item2 = (Item) context.getBean("item");
	      item2.setiCode(105);
	      item2.setiName("Rice 5");
	      item2.setiPrice(900);
	      Item item3 = (Item) context.getBean("item");
	      item3.setiCode(106);
	      item3.setiName("Rice 6");
	      item3.setiPrice(1000);*/
	      
	      
	      ItemDAO3 itemDAO = (ItemDAO3) context.getBean("itemDAO3");
	      /*itemDAO.addItem(item1);
	      itemDAO.addItem(item2);
	      itemDAO.addItem(item3);*/
	      
	      /*List<Item> items = itemDAO.getItems();
	      for(Item item:items){
	    	  System.out.println(item.getiCode());
	    	  System.out.println(item.getiName());
	    	  System.out.println(item.getiPrice());
	      }*/
	      
	      //Item item = itemDAO.getItem(101);for param1 with MappingSqlQuery icode
	      Item item = itemDAO.getItem(500); //MappingSqlQueryWithParameters with iprice
	      System.out.println(item.getiCode());
	      System.out.println(item.getiName());
	      System.out.println(item.getiPrice());

	}

}
