package com.sanjaya.jdbc.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.jdbcdemo.daos.ItemDAO;
import com.sanjaya.jdbcdemo.daos.ItemDAO2;
import com.sanjaya.jdbcdemo.pojo.Item;

public class JdbcDemoApp {
	
	public static void main(String[] args) {
		 
		ApplicationContext context = 
	             new ClassPathXmlApplicationContext("JdbcDaoDemoConfBeans.xml");

		/*Item item1 = (Item) context.getBean("item");
	      item1.setiCode(101);
	      item1.setiName("Rice 1");
	      item1.setiPrice(500);
	      Item item2 = (Item) context.getBean("item");
	      item2.setiCode(102);
	      item2.setiName("Rice 2");
	      item2.setiPrice(600);
	      Item item3 = (Item) context.getBean("item");
	      item3.setiCode(103);
	      item3.setiName("Rice 3");
	      item3.setiPrice(700);
	      
	      
	      ItemDAO itemDAO = (ItemDAO) context.getBean("itemDAO");
	      itemDAO.addItem(item1);
	      itemDAO.addItem(item2);
	      itemDAO.addItem(item3);
	      
	      List<Item> items = itemDAO.getItems();
	      for(Item item:items){
	    	  System.out.println(item.getiCode());
	    	  System.out.println(item.getiName());
	    	  System.out.println(item.getiPrice());
	      }*/
	      //System.out.println(obj.getMessage());
		
		ItemDAO itemDAO = (ItemDAO) context.getBean("itemDAO");
		Item item = itemDAO.getItem(106);
	      System.out.println(item.getiCode());
	      System.out.println(item.getiName());
	      System.out.println(item.getiPrice());

	}

}
