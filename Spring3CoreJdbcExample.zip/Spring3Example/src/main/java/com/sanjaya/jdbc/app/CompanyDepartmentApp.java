package com.sanjaya.jdbc.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sanjaya.jdbcdemo.daos.CompanyDepartmentDAO;
import com.sanjaya.jdbctemplate.pojo.Company;
import com.sanjaya.jdbctemplate.pojo.Department;


public class CompanyDepartmentApp {

	public CompanyDepartmentApp() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("CompanyDepartmentConf.xml");
		
		Company company = (Company) context.getBean("company");
		company.setCompanyName("CTS");
		company.setCompanyLevel("Level5");
		company.setCompanyRevenue(9900000);
		
		Department department = (Department) context.getBean("department");
		department.setDeptName("Finance");
		department.setVertical("Technical");
		department.setRevenue(1000.85);
		
		//System.out.println("Company Object : "+company);
		
		//System.out.println("Department Object : "+department);
		
		CompanyDepartmentDAO companyDepartmentDAO = (CompanyDepartmentDAO) context.getBean("companyDepartmentDAO");
		
		companyDepartmentDAO.addCompany(company, department);
		
		Company companyData = companyDepartmentDAO.getCompany(company.getCompanyName());
		
		List<Company> companyList = companyDepartmentDAO.getAllCompanies();
		
		Company company1 = (Company) context.getBean("company");
		company1.setCompanyRevenue(9800000);
		company.setCompanyName("CTS");
		company.setCompanyLevel("Level5");
		companyDepartmentDAO.updateCompany(company1);
		
		companyDepartmentDAO.deleteCompany(company1);
		
		
		
	}

}
